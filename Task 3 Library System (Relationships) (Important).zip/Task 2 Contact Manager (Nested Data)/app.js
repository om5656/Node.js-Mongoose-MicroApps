require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 8000;

const Contact = require("./models/Contact");

async function dbConnection() {
try {
await mongoose.connect(process.env.MONGO_URL);
console.log("Database Connected");
} catch (error) {
console.log(error);
}
}
dbConnection();

app.post("/api/contacts", async (req, res) => {
try {
const { fullName, phones, socialMedia } = req.body;

if (!fullName) {
return res.status(400).json({ msg: "Full name is required" });
}

const contact = await Contact.create({
fullName,
phones,
socialMedia,
});

res.status(201).json({
msg: "Contact created successfully",
data: contact,
});
} catch (error) {
res.status(500).json({ msg: "Server Error" });
}
});

app.get("/api/contacts", async (req, res) => {
try {
const contacts = await Contact.find();

res.status(200).json({
msg: "Contacts fetched successfully",
data: contacts,
});
} catch (error) {
res.status(500).json({ msg: "Server Error" });
}
});

app.listen(PORT, () => {
console.log(`Server running on port ${PORT}`);
});
