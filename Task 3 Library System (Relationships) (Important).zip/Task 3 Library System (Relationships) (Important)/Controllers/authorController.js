const Author = require("../models/Author");

exports.createAuthor = async (req, res) => {
  try {
    const { name } = req.body;

    if (!name) {
      return res.status(400).json({ msg: "Name is required" });
    }

    const author = await Author.create({ name });

    res.status(201).json({
      msg: "Author created successfully",
      data: author,
    });
  } catch (error) {
    res.status(500).json({ msg: "Server Error" });
  }
};

exports.getAuthors = async (req, res) => {
  try {
    const authors = await Author.find();
    res.status(200).json({
      msg: "Authors fetched successfully",
      data: authors,
    });
  } catch (error) {
    res.status(500).json({ msg: "Server Error" });
  }
};