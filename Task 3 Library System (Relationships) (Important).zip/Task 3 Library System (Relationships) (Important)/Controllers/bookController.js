const Book = require("../models/Book");

exports.createBook = async (req, res) => {
  try {
    const { title, author } = req.body;

    if (!title || !author) {
      return res.status(400).json({ msg: "Title and Author are required" });
    }

    const book = await Book.create({ title, author });

    res.status(201).json({
      msg: "Book created successfully",
      data: book,
    });
  } catch (error) {
    res.status(500).json({ msg: "Server Error" });
  }
};

exports.getBooks = async (req, res) => {
  try {
    const books = await Book.find().populate("author");

    res.status(200).json({
      msg: "Books fetched successfully",
      data: books,
    });
  } catch (error) {
    res.status(500).json({ msg: "Server Error" });
  }
};