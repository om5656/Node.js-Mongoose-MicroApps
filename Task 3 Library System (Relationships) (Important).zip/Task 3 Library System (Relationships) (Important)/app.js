require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 8000;

const Author = require("./models/Author");
const Book = require("./models/Book");

async function dbConnection() {
try {
await mongoose.connect(process.env.MONGO_URL);
console.log("Database Connected");
} catch (error) {
console.log(error);
}
}
dbConnection();


app.post("/api/authors", async (req, res) => {
try {
const { name } = req.body;

if (!name) {
return res.status(400).json({ msg: "Name is required" });
}

const author = await Author.create({ name });

res.status(201).json({
msg: "Author created successfully",
data: author,
});
} catch (error) {
res.status(500).json({ msg: "Server Error" });
}
});


app.post("/api/books", async (req, res) => {
try {
const { title, author } = req.body;

if (!title || !author) {
return res.status(400).json({ msg: "Title and Author are required" });
}

const book = await Book.create({
title,
author,
});

res.status(201).json({
msg: "Book created successfully",
data: book,
});
} catch (error) {
res.status(500).json({ msg: "Server Error" });
}
});


app.get("/api/books", async (req, res) => {
try {
const books = await Book.find().populate("author");

res.status(200).json({
msg: "Books fetched successfully",
data: books,
});
} catch (error) {
res.status(500).json({ msg: "Server Error" });
}
});

app.listen(PORT, () => {
console.log(`Server running on port ${PORT}`);
});
