const mongoose = require("mongoose");

const classroomSchema = new mongoose.Schema({
name: {
type: String,
required: true,
},
students: [
{
    type: mongoose.Schema.Types.ObjectId,
    ref: "Student",
},
],
});

const Classroom = mongoose.model("Classroom", classroomSchema);
module.exports = Classroom;
