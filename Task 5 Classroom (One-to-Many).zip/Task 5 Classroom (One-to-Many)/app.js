require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const app = express();
app.use(express.json());

const PORT = process.env.PORT || 8000;
const MONGO_URL = process.env.MONGO_URL;

const Student = require("./models/Student");
const Classroom = require("./models/Classroom");

async function dbConnection() {
try {
await mongoose.connect(MONGO_URL);
console.log("Database Connected");
} catch (error) {
console.log(error);
}
}
dbConnection();

app.post("/api/students", async (req, res) => {
try {
const student = await Student.create(req.body);
res.json({ msg: "Student created", data: student });
} catch (error) {
console.log(error);
res.json({ msg: "Error creating student" });
}
});

app.get("/api/students", async (req, res) => {
try {
const students = await Student.find();
res.json({ msg: "All students", data: students });
} catch (error) {
console.log(error);
res.json({ msg: "Error fetching students" });
}
});

app.post("/api/classrooms", async (req, res) => {
try {
const classroom = await Classroom.create(req.body);
res.json({ msg: "Classroom created", data: classroom });
} catch (error) {
console.log(error);
res.json({ msg: "Error creating classroom" });
}
});


app.get("/api/classrooms", async (req, res) => {
try {
const classrooms = await Classroom.find().populate("students", "name email");
res.json({ msg: "All classrooms", data: classrooms });
} catch (error) {
console.log(error);
res.json({ msg: "Error fetching classrooms" });
}
});

app.listen(PORT, () => {
console.log(`Server running on port ${PORT}`);
});
