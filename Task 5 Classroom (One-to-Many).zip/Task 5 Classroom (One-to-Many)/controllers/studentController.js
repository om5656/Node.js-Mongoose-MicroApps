const Student = require("../models/Student");

exports.createStudent = async (req, res) => {
  try {
    const student = await Student.create(req.body);
    res.json({ msg: "Student created", data: student });
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "Error creating student" });
  }
};

exports.getStudents = async (req, res) => {
  try {
    const students = await Student.find();
    res.json({ msg: "All students", data: students });
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "Error fetching students" });
  }
};