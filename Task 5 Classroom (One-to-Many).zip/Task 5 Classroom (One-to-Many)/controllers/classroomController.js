const Classroom = require("../models/Classroom");

exports.createClassroom = async (req, res) => {
  try {
    const classroom = await Classroom.create(req.body);
    res.json({ msg: "Classroom created", data: classroom });
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "Error creating classroom" });
  }
};

exports.getClassrooms = async (req, res) => {
  try {
    const classrooms = await Classroom.find().populate("students", "name email");
    res.json({ msg: "All classrooms", data: classrooms });
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "Error fetching classrooms" });
  }
};