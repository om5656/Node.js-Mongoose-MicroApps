const Task = require("../models/task");

exports.createTask = async (req, res) => {
try {
    const { title } = req.body;

    if (!title) {
        return res.status(400).json({ msg: "Title is required" });
    }

    const task = await Task.create({ title });

    res.status(201).json({
        msg: "Task created successfully",
        data: task,
    });

} catch (error) {
    res.status(500).json({ msg: "Server Error" });
}
};

exports.getTasks = async (req, res) => {
try {

    const tasks = await Task.find();

    res.status(200).json({
        msg: "Tasks fetched successfully",
        data: tasks,
    });

} catch (error) {
    res.status(500).json({ msg: "Server Error" });
}
};



