const Product = require("../models/Product");

exports.createProduct = async (req, res) => {
  try {
    const { name, category, price } = req.body;

    if (!name || !category || !price) {
      return res.status(400).json({ msg: "All fields are required" });
    }

    const product = await Product.create({ name, category, price });

    res.status(201).json({
      msg: "Product created successfully",
      data: product,
    });
  } catch (error) {
    res.status(500).json({ msg: "Server Error" });
  }
};

exports.getProducts = async (req, res) => {
  try {
    const products = await Product.find(req.query);

    res.status(200).json({
      msg: "Products fetched successfully",
      data: products,
    });
  } catch (error) {
    res.status(500).json({ msg: "Server Error" });
  }
};