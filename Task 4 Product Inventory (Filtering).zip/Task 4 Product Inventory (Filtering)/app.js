require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const MONGO_URL = process.env.MONGO_URL;

const Product = require("./models/Product");

async function dbConnection() {
try {
await mongoose.connect(MONGO_URL);
console.log("Database Connected");
} catch (error) {
console.log(error);
}
}
dbConnection();


app.post("/api/products", async (req, res) => {
try {
const { name, category, price } = req.body;

if (!name || !category || !price) {
return res.status(400).json({ msg: "All fields are required" });
}

const product = await Product.create({ name, category, price });

res.status(201).json({
msg: "Product created successfully",
data: product,
});
} catch (error) {
res.status(500).json({ msg: "Server Error" });
}
});

app.get("/api/products", async (req, res) => {
try {
const products = await Product.find(req.query);

res.status(200).json({
msg: "Products fetched successfully",
data: products,
});
} catch (error) {
res.status(500).json({ msg: "Server Error" });
}
});

app.listen(PORT, () => {
console.log(`Server running on port ${PORT}`);
});